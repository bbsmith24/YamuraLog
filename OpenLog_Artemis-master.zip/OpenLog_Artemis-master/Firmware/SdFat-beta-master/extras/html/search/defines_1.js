var searchData=
[
  ['dedicated_5fspi_990',['DEDICATED_SPI',['../_sd_spi_driver_8h.html#a666c394438267afda9b1e63f6b61459c',1,'SdSpiDriver.h']]],
  ['destructor_5fcloses_5ffile_991',['DESTRUCTOR_CLOSES_FILE',['../_sd_fat_config_8h.html#a9a2b1ca4d91cff876f48deeaacbc33da',1,'SdFatConfig.h']]]
];
