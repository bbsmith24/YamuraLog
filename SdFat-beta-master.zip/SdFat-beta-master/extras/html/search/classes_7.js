var searchData=
[
  ['minimumserial_532',['MinimumSerial',['../class_minimum_serial.html',1,'']]],
  ['myspiclass_533',['MySpiClass',['../class_my_spi_class.html',1,'']]]
];
